## Team submission code drop 1

Please refer to the readme.mds in the sub folders for instructions on how to interpret each piece of the project.

There are 3 datasets and hence 3 parts
- solar
- soil
- weather

each comes from a different sources and uses different processing in order to get it to the final state that is then mapped together with Hive and SQL and Hive

The mapping code can be fund in the .sql file in the root directory
