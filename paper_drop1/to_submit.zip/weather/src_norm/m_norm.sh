#!/bin/bash

. /etc/profile.d/modules.sh
module load python/gnu/3.6.5
src_norm/m_norm.py