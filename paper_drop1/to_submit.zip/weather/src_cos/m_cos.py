#!/usr/bin/env python

import sys

for l in sys.stdin:
    a = l.strip()
    print(a)
