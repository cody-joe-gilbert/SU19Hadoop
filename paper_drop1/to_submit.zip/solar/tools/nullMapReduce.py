#!/usr/bin/python
"""
CSCI-GA.3033-003 - Project: Finding Napa
R. Feng, C. Gilbert, G. Ng

NULL MR script: Dummy mapper/reducer that simply returns the output
of the input key-value string

@author: Cody Gilbert
"""
import sys
for line in sys.stdin:
    print(line.strip())
